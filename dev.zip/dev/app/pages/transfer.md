<div id="myarticle">
<h1 id="HomeTitle">Transfer</h1>
<p>
A web application that has built in templates for One Time Transaction Documents used for Onerous and Gratuitous BIR transfers. And a guide to which BIR forms should be used for certain and specific transaction, that is needed to be attached with the Document that the user made using the app. The user will just input the data according to the user’s choice of document to be constructed. And a link to the various on BIR Forms that needs to be filled up along with said document will also appear to help and guide the user. 
</p>
</div>